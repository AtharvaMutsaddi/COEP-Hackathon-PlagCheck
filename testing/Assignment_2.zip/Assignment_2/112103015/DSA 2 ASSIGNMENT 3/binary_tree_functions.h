#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include "binary_tree_class.h"

bt_node* create_a_bt_node(char ch)
{
    bt_node *new_node=(bt_node *)malloc(sizeof(bt_node)*1);
    new_node->ch=ch;
    new_node->left=NULL;
    new_node->right=NULL;
    return new_node;
}

bt_node_ll *create_a_bt_node_ll(bt_node *bnode)
{
    bt_node_ll *new_bt_node_ll=(bt_node_ll *)malloc(sizeof(bt_node_ll)*1);
    new_bt_node_ll->bnode=bnode;
    new_bt_node_ll->next=NULL;
    return new_bt_node_ll;
}

bt_node_stack *create_a_bt_node_stack()
{
    bt_node_stack *new_bt_node_stack=(bt_node_stack*)malloc(sizeof(bt_node_stack)*1);
    new_bt_node_stack->size=0;
    new_bt_node_stack->front=NULL;
    return new_bt_node_stack;
}

void push_into_bt_node_stack(bt_node *bnode,bt_node_stack *s)
{
    bt_node_ll *new_bt_node_ll=create_a_bt_node_ll(bnode);
    new_bt_node_ll->next=s->front;
    s->front=new_bt_node_ll;
    s->size+=1;
    return;
}

void pop_from_bt_node_stack(bt_node_stack *s)
{
    if(s->size==0)
    {
        printf("\nThe stack is empty so cannot pop any bt_node from it.\n");
        return;
    }
    else
    {
        s->front=s->front->next;
        s->size-=1;
        return;
    }
}

bt_node *top_of_bt_node_stack(bt_node_stack *s)
{
    if(s->size==0)
    {
        printf("\nThe stack is empty so their is no top bt_node in it.\n");
        return NULL;
    }
    else
    {
        return s->front->bnode;
    }
}

bool is_bt_node_stack_empty(bt_node_stack *s)
{
    return s->size==0;
}

int size_of_bt_node_stack(bt_node_stack *s)
{
    return s->size;
}

int height_of_bt(bt_node *root)
{
    if(root==NULL)
    {
        return 0;
    }
    int lheight=height_of_bt(root->left);
    int rheight=height_of_bt(root->right);
    if(lheight>=rheight)
    {
        return 1+lheight;
    }
    else
    {
        return 1+rheight;
    }
}

void print_inorder_traversal(bt_node *root)
{
    if(root==NULL)
    {
        return;
    }
    print_inorder_traversal(root->left);
    printf("%c ",root->ch);
    print_inorder_traversal(root->right);
    return;
}

void print_preorder_traversal(bt_node *root)
{
    if(root==NULL)
    {
        return;
    }
    printf("%c ",root->ch);
    print_preorder_traversal(root->left);
    print_preorder_traversal(root->right);
    return;
}

void print_postorder_traversal(bt_node *root)
{
    if(root==NULL)
    {
        return;
    }
    print_postorder_traversal(root->left);
    print_postorder_traversal(root->right);
    printf("%c ",root->ch);
    return;
}

void printCurrentLevel(bt_node *root,int level)
{
    if(root==NULL)
    {
        return;
    }
    if(level==1)
    {
        printf("%c ",root->ch);
        return;
    }
    else if(level>1)
    {
        printCurrentLevel(root->left,level-1);
        printCurrentLevel(root->right,level-1);
        return;
    }
}

void print_levelorder_traversal(bt_node *root)
{
    int h=height_of_bt(root);
    for(int i=1;i<=h;i+=1)
    {
        printCurrentLevel(root,i);
    }
    return;
}
