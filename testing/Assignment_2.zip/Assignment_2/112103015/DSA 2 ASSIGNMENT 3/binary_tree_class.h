#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>

typedef struct bt_node{
    char ch;
    struct bt_node *left;
    struct bt_node *right;
}bt_node;

typedef struct bt_node_ll{
    bt_node *bnode;
    struct bt_node_ll *next;
}bt_node_ll;

typedef struct bt_node_stack{
    int size;
    bt_node_ll *front;
}bt_node_stack;

bt_node* create_a_bt_node(char ch);

bt_node_ll *create_a_bt_node_ll(bt_node *bnode);

bt_node_stack *create_a_bt_node_stack();

void push_into_bt_node_stack(bt_node *bnode,bt_node_stack *s);

void pop_from_bt_node_stack(bt_node_stack *s);

bt_node *top_of_bt_node_stack(bt_node_stack *s);

bool is_bt_node_stack_empty(bt_node_stack *s);

int size_of_bt_node_stack(bt_node_stack *s);

int height_of_bt(bt_node *root);

void print_inorder_traversal(bt_node *root);

void print_preorder_traversal(bt_node *root);

void print_postorder_traversal(bt_node *root);

void print_levelorder_traversal(bt_node *root);