#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "binary_tree_functions.h"
#define STRING_SIZE 100

bool is_operator(char ch)
{
    return ch == '+' || ch == '-' || ch == '*' || ch == '/';
}

int operator_precedence(char ch)
{
    if (ch == '+' || ch == '-')
    {
        return 1;
    }
    else if (ch == '*' || ch == '/')
    {
        return 2;
    }
    else
    {
        return 0;
    }
}

int main()
{
    char expr[STRING_SIZE];
    printf("Enter the expression here without spaces : ");
    fgets(expr, STRING_SIZE, stdin);
    printf("The enetered expression is:%s", expr);
    printf("The length of string including the NULL character is %d",strlen(expr));
    // CREATING THE TWO STACK ONE FOR OPERAND AND ANOTHER FOR THE OPERATORS
    bt_node_stack *operator_stack = create_a_bt_node_stack();
    bt_node_stack *operand_stack = create_a_bt_node_stack();

    int i = 0;
    while (i < strlen(expr)-1 )//as the null char is should not be counted)
    {
        char curr = expr[i];
        if (curr == '(')
        {
            // IF IT IS OPENING BRACKET WE WILL SIMPLY PUSH IT ONTO THE OPERATOR STACK
            bt_node *temp = create_a_bt_node(curr);
            push_into_bt_node_stack(temp, operator_stack);
            i += 1;
            continue;
        }
        if (curr == ')')
        {
            // SO THIS IS THE CLOSING BRACKET NOW WE HAVE TO JUST POP FROM THE OPERATOR STACK UNTILL WE GET THE OPENING BRACKET
            while (is_bt_node_stack_empty(operator_stack) != true && top_of_bt_node_stack(operator_stack)->ch != '(')
            {
                bt_node *helper = top_of_bt_node_stack(operator_stack);
                pop_from_bt_node_stack(operator_stack);
                bt_node *right_child = top_of_bt_node_stack(operand_stack);
                pop_from_bt_node_stack(operand_stack);
                bt_node *left_child = top_of_bt_node_stack(operand_stack);
                pop_from_bt_node_stack(operand_stack);
                helper->left = left_child;
                helper->right = right_child;
                push_into_bt_node_stack(helper, operand_stack);
            }
            if (is_bt_node_stack_empty(operator_stack) != true)
            {
                pop_from_bt_node_stack(operator_stack);
            }

            i += 1;
            continue;
        }
        if (is_operator(curr) == true)
        {
            // SO THIS IS OPERATOR AND WE NEED TO PUSH IT ONTO THE OPERATOR STACK AFTER PERFORMING SOME FILTERATIONS FIRST.
            while (is_bt_node_stack_empty(operator_stack) != true && operator_precedence(top_of_bt_node_stack(operator_stack)->ch) >= operator_precedence(curr))
            {
                bt_node *helper = top_of_bt_node_stack(operator_stack);
                pop_from_bt_node_stack(operator_stack);
                bt_node *right_child = top_of_bt_node_stack(operand_stack);
                pop_from_bt_node_stack(operand_stack);
                bt_node *left_child = top_of_bt_node_stack(operand_stack);
                pop_from_bt_node_stack(operand_stack);
                helper->left = left_child;
                helper->right = right_child;
                push_into_bt_node_stack(helper, operand_stack);
            }

            bt_node *temp = create_a_bt_node(curr);
            push_into_bt_node_stack(temp, operator_stack);
            i += 1;
            continue;
        }
        
        // THIS MEANS IT IS A OPERAND.
        bt_node *temp = create_a_bt_node(curr);
        push_into_bt_node_stack(temp, operand_stack);
        i += 1;
    }

    while (is_bt_node_stack_empty(operator_stack) != true)
    {
        bt_node *helper = top_of_bt_node_stack(operator_stack);
        pop_from_bt_node_stack(operator_stack);
        if(helper->ch=='(')
        {
            continue;
        }
        bt_node *right_child = top_of_bt_node_stack(operand_stack);
        pop_from_bt_node_stack(operand_stack);
        bt_node *left_child = top_of_bt_node_stack(operand_stack);
        pop_from_bt_node_stack(operand_stack);
        helper->left = left_child;
        helper->right = right_child;
        push_into_bt_node_stack(helper, operand_stack);
    }

    printf("\nThe inorder traversal of the expression tree is : ");
    print_inorder_traversal(top_of_bt_node_stack(operand_stack));

    printf("\nThe preorder traversal of the expression tree is : ");
    print_preorder_traversal(top_of_bt_node_stack(operand_stack));

    printf("\nThe postorder traversal of the expression tree is : ");
    print_postorder_traversal(top_of_bt_node_stack(operand_stack));

    printf("\nThe levelorder traversal of the expression tree is : ");
    print_levelorder_traversal(top_of_bt_node_stack(operand_stack));

    return 0;
}