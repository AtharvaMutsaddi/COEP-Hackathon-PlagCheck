#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<limits.h>
#include "binary_tree_class.h"

binary_tree_node *create_a_binary_tree_node(int data)
{
    binary_tree_node *new_node=(binary_tree_node *)malloc(sizeof(binary_tree_node)*1);
    new_node->data=data;
    new_node->left=NULL;
    new_node->right=NULL;
    return new_node;
}

binary_tree *create_a_binary_tree(int root_data)
{
    binary_tree *new_tree=(binary_tree *)malloc(sizeof(binary_tree)*1);
    new_tree->root=create_a_binary_tree_node(root_data);
    return new_tree;
}

void print_inorder_of_binary_tree(binary_tree_node *root)
{
    if(root==NULL)
    {
        return;
    }
    print_inorder_of_binary_tree(root->left);
    printf("%d ",root->data);
    print_inorder_of_binary_tree(root->right);
    return;
}

int max_in_left_subtree(binary_tree_node *root)
{
    if(root==NULL)
    {
        return INT_MIN;
    }
    int small_ans=max_in_left_subtree(root->right);
    if(small_ans>root->data)
    {
        return small_ans;
    }
    else
    {
        return root->data;
    }
}

int min_in_right_subtree(binary_tree_node *root)
{
    if(root==NULL)
    {
        return INT_MAX;
    }
    int small_ans=min_in_right_subtree(root->left);
    if(small_ans<root->data)
    {
        return small_ans;
    }
    else
    {
        return root->data;
    }
}

bool check_if_BST(binary_tree_node *root)
{
    if(root==NULL)
    {
        return true;
    }
    if(root->left==NULL && root->right==NULL)
    {
        return true;
    }

    int left_max=max_in_left_subtree(root->left);
    int right_min=min_in_right_subtree(root->right);
    if(left_max<root->data && root->data<right_min)
    {
       return check_if_BST(root->left) && check_if_BST(root->right);
    }
    else
    {
        return false;
    }
    
}
