#include<stdlib.h>
#include<stdio.h>
#include<limits.h>
#include<stdbool.h>

typedef struct binary_tree_node{
    int data;
    struct binary_tree_node *left;
    struct binary_tree_node *right;
}binary_tree_node;

typedef struct binary_tree{
    binary_tree_node *root;
}binary_tree;

binary_tree_node *create_a_binary_tree_node(int data);

binary_tree *create_a_binary_tree(int root_data);

void print_inorder_of_binary_tree(binary_tree_node *root);

bool check_if_BST(binary_tree_node *root);