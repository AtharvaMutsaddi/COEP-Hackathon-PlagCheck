#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<limits.h>
#include "binary_tree_functions.h"

int main()
{
    binary_tree *new_tree=create_a_binary_tree(5);
    binary_tree_node *root=new_tree->root;
    root->left=create_a_binary_tree_node(1);
    root->right=create_a_binary_tree_node(4);
    root->right->left=create_a_binary_tree_node(1);
    root->right->right=create_a_binary_tree_node(3);
    print_inorder_of_binary_tree(root);
    printf("\n%d",check_if_BST(root));
    return 0;
}